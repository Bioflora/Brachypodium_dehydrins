package es.uma.motif;

public class ResultPair {
    public int pos;
    public int qty;
}
